// src/handler.ts
import { createLogger, format, transports } from "winston";

// src/logAggregator/boonsCalculations.ts
var calculatePlayerBoonStats = (playerLogs) => {
  const buffUptimes = playerLogs.flatMap((log) => log.buffUptimes).map((buffUptimes2) => {
    return {
      boon: buffUptimes2.id,
      uptime: buffUptimes2.buffData[0].uptime
    };
  });
  const aggregateBuffUptimes = [];
  buffUptimes.forEach((buffUptime) => {
    if (playerLogs[0].account === "Lufarianor.5964" && buffUptime.boon === 719)
      console.log("Buff number has value: " + JSON.stringify(buffUptime));
    if (aggregateBuffUptimes[buffUptime.boon]) {
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: buffUptime.boon,
        uptime: Number.parseFloat(
          ((aggregateBuffUptimes[buffUptime.boon].uptime + buffUptime.uptime) / 2).toFixed(2)
        )
      };
    } else
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: aggregateBuffUptimes[buffUptime.boon],
        uptime: buffUptime.uptime
      };
  });
  return aggregateBuffUptimes;
};
var calculatePlayerGroupBoonStats = (playerLogs) => {
  const buffUptimes = playerLogs.flatMap((log) => log.groupBuffs).filter((buffData) => !!buffData).map((groupBuffs) => {
    return {
      boon: groupBuffs.id,
      generation: groupBuffs.buffData[0].generation
    };
  });
  const aggregateBuffUptimes = [];
  buffUptimes.forEach((buffUptime) => {
    console.log(buffUptime);
    if (aggregateBuffUptimes[buffUptime.boon]) {
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: buffUptime.boon,
        generation: Number.parseFloat(
          ((aggregateBuffUptimes[buffUptime.boon].generation + buffUptime.generation) / 2).toFixed(2)
        )
      };
    } else
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: aggregateBuffUptimes[buffUptime.boon],
        generation: buffUptime.generation
      };
  });
  console.log(aggregateBuffUptimes);
  return aggregateBuffUptimes;
};
var calculatePlayerSquadBoonStats = (playerLogs) => {
  const buffUptimes = playerLogs.flatMap((log) => log.squadBuffs).filter((buffData) => !!buffData).map((squadBuffs) => {
    return {
      boon: squadBuffs.id,
      generation: squadBuffs.buffData[0].generation
    };
  });
  const aggregateBuffUptimes = [];
  buffUptimes.forEach((buffUptime) => {
    if (aggregateBuffUptimes[buffUptime.boon]) {
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: buffUptime.boon,
        generation: Number.parseFloat(
          ((aggregateBuffUptimes[buffUptime.boon].generation + buffUptime.generation) / 2).toFixed(2)
        )
      };
    } else
      aggregateBuffUptimes[buffUptime.boon] = {
        boon: aggregateBuffUptimes[buffUptime.boon],
        generation: buffUptime.generation
      };
  });
  console.log(aggregateBuffUptimes);
  return aggregateBuffUptimes;
};

// src/logAggregator/calculateAverageData.ts
var calculatePlayerTimeAverageData = (playerData) => {
  return {
    playerAvgDamagePerSec: parseFloat((playerData.totalDamage / (playerData.playerActiveTime / 1e3)).toFixed(2)),
    playerAvgCleansePerSec: parseFloat(
      (playerData.playerCleanses / (playerData.playerActiveTime / 1e3)).toFixed(2)
    ),
    playerAvgStripsPerSec: parseFloat((playerData.playerStrips / (playerData.playerActiveTime / 1e3)).toFixed(2)),
    playerAvgDamageTaken: parseFloat(
      (playerData.playerDamageTaken / (playerData.playerActiveTime / 1e3)).toFixed(2)
    ),
    playerAvgDownsPerSec: parseFloat((playerData.playerDowns / (playerData.playerActiveTime / 1e3)).toFixed(5)),
    playerAvgDeathsPerSec: parseFloat((playerData.playerDeaths / (playerData.playerActiveTime / 1e3)).toFixed(5))
  };
};

// src/logAggregator/groupDataByCharacterName.ts
var groupDataByCharacterName = (logData) => {
  const activePlayers = {};
  logData.forEach((log) => {
    log.players.forEach((player) => {
      if (activePlayers[player.name]) {
        activePlayers[player.name].push(player);
      } else {
        activePlayers[player.name] = [player];
      }
    });
  });
  return activePlayers;
};

// src/logAggregator/playerLogic.ts
var calculateTotalActiveCombatTime = (playerLogs) => {
  return playerLogs.flatMap((log) => log.activeTimes).reduce((prev, curr) => prev + curr, 0);
};
var calculateTotalSelfCleanse = (playerLogs) => {
  return playerLogs.flatMap((log) => log.support).map((support) => support.condiCleanseSelf).reduce((prev, curr) => prev + curr, 0);
};
var calculateTotalOtherCleanse = (playerLogs) => {
  return playerLogs.flatMap((log) => log.support).map((support) => support.condiCleanse).reduce((prev, curr) => prev + curr, 0);
};
var calculateTotalCleanses = (playerLogs) => {
  return playerLogs.flatMap((log) => log.support).map((support) => support.condiCleanse + support.condiCleanseSelf).reduce((prev, curr) => prev + curr, 0);
};
var calculateTotalStrips = (playerLogs) => {
  return playerLogs.flatMap((log) => log.support).map((support) => support.boonStrips).reduce((prev, curr) => prev + curr, 0);
};
var calculateAverageDistToCom = (playerLogs) => {
  const miscStats = playerLogs.flatMap((log) => log.statsAll).filter((stats) => stats.distToCom != 0);
  return Math.round(
    miscStats.map((stats) => stats.distToCom).reduce((prev, curr) => prev + curr, 0) / miscStats.length
  );
};
var calculateAverageDistToSquad = (playerLogs) => {
  const miscStats = playerLogs.flatMap((log) => log.statsAll).filter((stats) => stats.stackDist != 0);
  return Math.round(
    miscStats.map((stats) => stats.stackDist).reduce((prev, curr) => prev + curr, 0) / miscStats.length
  );
};
var calculatePlayerDamageStats = (playerLogs) => {
  return playerLogs.flatMap((log) => log.dpsAll).map((dpsStats) => {
    return {
      totalDamage: dpsStats.damage,
      totalPowerDamage: dpsStats.powerDamage,
      totalCondiDamage: dpsStats.condiDamage
    };
  }).reduce(
    (damageTotals, currentStats) => {
      Object.keys(damageTotals).forEach((key) => damageTotals[key] += currentStats[key]);
      return damageTotals;
    },
    {
      totalDamage: 0,
      totalPowerDamage: 0,
      totalCondiDamage: 0
    }
  );
};
var calculatePlayerDamageTakenStats = (playerLogs) => {
  return playerLogs.flatMap((log) => log.defenses).map((defenses) => {
    return {
      playerDamageTaken: defenses.damageTaken,
      playerBarrierDamageTaken: defenses.damageBarrier,
      playerDowns: defenses.downCount,
      playerDeaths: defenses.deadCount
    };
  }).reduce(
    (damageTotals, currentStats) => {
      Object.keys(damageTotals).forEach((key) => damageTotals[key] += currentStats[key]);
      return damageTotals;
    },
    {
      playerDamageTaken: 0,
      playerBarrierDamageTaken: 0,
      playerDowns: 0,
      playerDeaths: 0
    }
  );
};
var calculatePlayerTargetDamageStats = (playerLogs) => {
  return playerLogs.flatMap((log) => log.dpsTargets).flat(1).map((targetDpsStats) => {
    return {
      totalTargetDamage: targetDpsStats.damage,
      totalTargetPowerDamage: targetDpsStats.powerDamage,
      totalTargetCondiDamage: targetDpsStats.condiDamage
    };
  }).reduce(
    (damageTotals, currentStats) => {
      Object.keys(damageTotals).forEach((key) => damageTotals[key] += currentStats[key]);
      return damageTotals;
    },
    {
      totalTargetDamage: 0,
      totalTargetPowerDamage: 0,
      totalTargetCondiDamage: 0
    }
  );
};

// src/logAggregator/logAggregator.ts
import AdmZip from "adm-zip";
var aggregateJSONLogs = (req) => {
  console.log("Attempting to aggregate JSON log files");
  const logData = [];
  const zip = new AdmZip(req.files[0].buffer);
  console.log("Recieved zipped file: ", zip);
  const zipEntries = zip.getEntries();
  zipEntries.forEach((file) => {
    console.log("Processing entry: ", file.getData());
    const jsonData = JSON.parse(file.getData().toString());
    console.log(`Parsed data for log recorded at: ${jsonData.timeStart} by ${jsonData.recordedBy}`);
    logData.push(jsonData);
  });
  const players = groupDataByCharacterName(logData);
  const strippedDownStats = [];
  for (const [key, value] of Object.entries(players)) {
    strippedDownStats.push({
      playerName: key,
      playerRoundsActive: value.length,
      playerActiveTime: calculateTotalActiveCombatTime(value),
      playerStrips: calculateTotalStrips(value),
      playerCleanses: calculateTotalCleanses(value),
      playerSelfCleanses: calculateTotalSelfCleanse(value),
      playerOtherCleanses: calculateTotalOtherCleanse(value),
      playerDistanceToCom: calculateAverageDistToCom(value),
      playerDistanceToStack: calculateAverageDistToSquad(value),
      // 'playerAvgDamageTaken',
      playerBoons: { ...calculatePlayerBoonStats(value) },
      //@ts-ignore
      playerBoonsGroup: { ...calculatePlayerGroupBoonStats(value) },
      //@ts-ignore
      playerBoonsSquad: { ...calculatePlayerSquadBoonStats(value) },
      ...calculatePlayerDamageTakenStats(value),
      ...calculatePlayerDamageStats(value),
      ...calculatePlayerTargetDamageStats(value)
    });
  }
  const statsStitchedAverages = [];
  strippedDownStats.forEach((playerStats) => {
    statsStitchedAverages.push({ ...playerStats, ...calculatePlayerTimeAverageData(playerStats) });
  });
  console.log("Returning aggregated stats: ", statsStitchedAverages[0]);
  return statsStitchedAverages;
};

// src/handler.ts
var handler = async (event, context) => {
  const logger = createLogger({
    level: "info",
    format: format.combine(
      format.timestamp({
        format: "YYYY-MM-DD HH:mm:ss"
      }),
      format.errors({ stack: true }),
      format.splat(),
      format.json()
    ),
    defaultMeta: { service: "gw2-aggregator-lambda" },
    transports: [new transports.Console()]
  });
  logger.info("Processing event: \n" + JSON.stringify(event, null, 2));
  return aggregateJSONLogs(event);
};
export {
  handler
};
